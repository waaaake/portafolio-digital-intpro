﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace circulo_ADGM_1369923
{
    internal class Program
    {
        class TrianguloRectangulo
        {
            private double catetoA;
            private double anguloOpuestoA;

            public TrianguloRectangulo(double valorCatetoA, double valorAnguloOpuestoA)
            {
                catetoA = valorCatetoA;
                anguloOpuestoA = valorAnguloOpuestoA;
            }

            public double ObtenerCatetoA()
            {
                return catetoA;
            }

            public double ObtenerCatetoB()
            {
                double catetoB = catetoA / Math.Tan(anguloOpuestoA * Math.PI / 180.0);
                return Math.Round(catetoB, 3);
            }

            public double ObtenerHipotenusa()
            {
                double hipotenusa = catetoA / Math.Sin(anguloOpuestoA * Math.PI / 180.0);
                return Math.Round(hipotenusa, 3);
            }

            public double ObtenerAnguloOpuestoA()
            {
                return anguloOpuestoA;
            }

            public double ObtenerAnguloOpuestoB()
            {
                double anguloOpuestoB = 90 - anguloOpuestoA;
                return Math.Round(anguloOpuestoB, 3);
            }

            public double ObtenerArea()
            {
                double catetoB = ObtenerCatetoB();
                double area = 0.5 * catetoA * catetoB;
                return Math.Round(area, 3);
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                double catetoA, anguloOpuestoA;

                Console.Write("Ingrese la longitud del cateto A en metros: ");
                catetoA = double.Parse(Console.ReadLine());

                Console.Write("Ingrese el ángulo opuesto a cateto A en grados: ");
                anguloOpuestoA = double.Parse(Console.ReadLine());
ulo
                TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

                Console.WriteLine("Valor de cateto A: " + objTriangulo.ObtenerCatetoA() + " metros");
                Console.WriteLine("Valor de cateto B: " + objTriangulo.ObtenerCatetoB() + " metros");
                Console.WriteLine("Valor de hipotenusa: " + objTriangulo.ObtenerHipotenusa() + " metros");
                Console.WriteLine("Valor de ángulo opuesto de A: " + objTriangulo.ObtenerAnguloOpuestoA() + " grados");
                Console.WriteLine("Valor de ángulo opuesto de B: " + objTriangulo.ObtenerAnguloOpuestoB() + " grados");
                Console.WriteLine("Valor de área: " + objTriangulo.ObtenerArea() + " metros cuadrados");
            }
        }
